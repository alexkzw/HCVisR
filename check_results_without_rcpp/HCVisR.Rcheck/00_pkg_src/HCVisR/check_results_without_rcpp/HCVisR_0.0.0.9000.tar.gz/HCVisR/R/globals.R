utils::globalVariables(c("x", "y", "C", "Dimension", "H", "Side"))
